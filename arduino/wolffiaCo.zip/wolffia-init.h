//
//  wolffia-init.h
//  wolffiaCo
//
//  Created by Parker Kane on 19/02/2014.
//  Copyright (c) 2014 Parker Kane. All rights reserved.
//

#ifndef wolffiaCo_wolffia_init_h
#define wolffiaCo_wolffia_init_h

#include <stdint.h>

#include "wolffia-task.h"

#endif
