//
//  wolffia-buffer.h
//  wolffiaCo
//
//  Created by Timo Reunanen on 19/02/2014.
//  Copyright (c) 2014 Timo Reunanen. All rights reserved.
//

#ifndef __wolffiaCo__wolffia_buffer__
#define __wolffiaCo__wolffia_buffer__

#include <stdint.h>

#endif /* defined(__wolffiaCo__wolffia_buffer__) */
